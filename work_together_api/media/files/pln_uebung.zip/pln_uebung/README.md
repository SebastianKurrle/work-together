# vue-scf-starter

Starter Template für die Verwendung von Vue-Single-File-Components

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```
