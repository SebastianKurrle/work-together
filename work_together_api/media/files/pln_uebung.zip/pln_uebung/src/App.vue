<script setup>
import { ref, reactive } from 'vue'

const num1 = ref(0)
const num2 = ref(0)
const res = ref(0)
const num1Error = ref(false)
const num2Error = ref(false)

const letzteRes = reactive([])

function rechnen() {
  res.value = Number(num1.value) + Number(num2.value)

  letzteRes.push(res.value)
}

function validate() {
  num1Error.value = false
  num2Error.value = false

  if (isNaN(num1.value)) {
    num1Error.value = true
  }

  if (isNaN(num2.value)) {
    num2Error.value = true
  }
}

</script>

<template>
  <div class="app">
    <header>
      <h1>Rechner</h1>
    </header>

    <main>
      <div>
        <label for="num1">Zahl1</label>
        <input type="text" id="num1" v-model="num1" @input="validate">
        <p class="error" v-if="num1Error">Bitte eine Zahl eingeben</p>
        <p v-else>Passt</p>
        
        <label for="num2">Zahl2</label>
        <input type="text" id="num2"  @input="validate" v-model="num2">
        <p class="error" v-if="num2Error">Bitte eine Zahl eingeben</p>

        <button @click="rechnen">Rechnen</button>

        <p>Ergebnis: {{ res }}</p>

        <div>
          <h5>Letzte Ergebnisse:</h5>
          <p v-for="res in letzteRes">{{ res }}</p>
        </div>
      </div>
    </main>
  </div>
</template>

<style scoped>
.app {
  background-color: darkcyan;
  box-shadow: 2px 2px 2px black;
  padding-bottom: 1em;
}

h1 {
  padding: 0.5em;
  text-shadow: 2px 2px 2px white;
}

.error {
  color: red;
}
</style>
